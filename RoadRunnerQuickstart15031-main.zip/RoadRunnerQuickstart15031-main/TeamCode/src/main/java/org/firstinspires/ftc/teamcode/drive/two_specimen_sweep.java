package org.firstinspires.ftc.teamcode.drive;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.control.PIDCoefficients;
import com.acmerobotics.roadrunner.drive.DriveSignal;
import com.acmerobotics.roadrunner.drive.MecanumDrive;
import com.acmerobotics.roadrunner.followers.HolonomicPIDVAFollower;
import com.acmerobotics.roadrunner.followers.TrajectoryFollower;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.acmerobotics.roadrunner.trajectory.TrajectoryBuilder;
import com.acmerobotics.roadrunner.trajectory.constraints.AngularVelocityConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.MecanumVelocityConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.MinVelocityConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.ProfileAccelerationConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.TrajectoryAccelerationConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.TrajectoryVelocityConstraint;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;

import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequence;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequenceBuilder;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequenceRunner;
import org.firstinspires.ftc.teamcode.util.LynxModuleUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MAX_ACCEL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MAX_ANG_ACCEL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MAX_ANG_VEL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MAX_VEL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MOTOR_VELO_PID;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.RUN_USING_ENCODER;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.TRACK_WIDTH;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.encoderTicksToInches;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.kA;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.kStatic;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.kV;

@Autonomous (name = "Two Specimen; Preload, Human Player, Two Sweeps")
public class two_specimen_sweep extends LinearOpMode {
    public void runOpMode(){

        // calls SampleMecanumDrive as a class and creates object
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);

        // lift motor initialization
        DcMotor liftExtendMotor = hardwareMap.dcMotor.get("liftExtendMotor");
        DcMotor liftExtendMotor1 = hardwareMap.dcMotor.get("liftExtendMotor1");
        DcMotor liftRotateMotor = hardwareMap.dcMotor.get("liftRotateMotor");

        liftRotateMotor.setDirection(DcMotorSimple.Direction.REVERSE);

        // only using arm motor, encoder initialization

        Servo LeftClawServo = hardwareMap.get(Servo.class, "LeftClawServo");
        Servo RightClawServo = hardwareMap.get(Servo.class, "RightClawServo");

        LeftClawServo.setPosition(1);
        RightClawServo.setPosition(0);

        sleep(250);

        liftRotateMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        liftRotateMotor.setTargetPosition(450);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        Pose2d startPose = new Pose2d(0, 0, Math.toRadians(0));
        drive.setPoseEstimate(startPose);



        // drive up to submersible diagonally (1st specimen)
        Trajectory drive_to_submersible = drive.trajectoryBuilder(new Pose2d())
                .lineTo(new Vector2d(29, 7.5))
                .build();

        Trajectory back = drive.trajectoryBuilder(new Pose2d(29, 7.5, Math.toRadians(0)))
                .back(8)
                .build();

        Trajectory to_ground_specimen_strafe = drive.trajectoryBuilder(new Pose2d(21, 7.5, Math.toRadians(0)))
                .lineTo(new Vector2d(30, -31.5))
                .build();

        Trajectory backward_human_player_delivery = drive.trajectoryBuilder(new Pose2d(30, -31.5, Math.toRadians(0)))
                .lineToLinearHeading(new Pose2d(19, -30, Math.toRadians(-135)))
                .build();

        Trajectory backward_realignment_for_second = drive.trajectoryBuilder(new Pose2d(19, -30, Math.toRadians(-135)))
                .lineTo(new Vector2d(24, -16))
                .build();

        Trajectory second_fwd = drive.trajectoryBuilder(new Pose2d(24, -16, Math.toRadians(-135)))
                .lineTo(new Vector2d(24.5, -19))
                .build();


        Trajectory second_specimen_to_submersible = drive.trajectoryBuilder(new Pose2d(24.5, -19, Math.toRadians(-135)))
                .splineToLinearHeading(new Pose2d (22.5, 16.5, Math.toRadians(0)), Math.toRadians(0))
                .build();

        Trajectory slight_fwd = drive.trajectoryBuilder(new Pose2d(22.5, 16.5, Math.toRadians(0)))
                .forward(3.5)
                .build();

        Trajectory back2 = drive.trajectoryBuilder(new Pose2d(22.5, 19.5, Math.toRadians(0)))
                .back(4)
                .build();

        Trajectory right_strafe_after_second  = drive.trajectoryBuilder(new Pose2d(18.5, 19.5, Math.toRadians(0)))
                .strafeRight(25)
                        .build();

        Trajectory diagonal_sweep = drive.trajectoryBuilder(new Pose2d(18.5, -5.5, Math.toRadians(0)))
                .lineToLinearHeading(new Pose2d (74, -34.5, Math.toRadians(115)))
                        .build();

        Trajectory left_sweep = drive.trajectoryBuilder(new Pose2d (74, -34.5, Math.toRadians(115)))
                .strafeLeft(45)
                .build();

        /*

        Trajectory to_human_player_third_specimen  = drive.trajectoryBuilder(new Pose2d(18.5, 19.5, Math.toRadians(0)))
                .lineToLinearHeading(new Pose2d(21, -17, Math.toRadians(-135)))
                .build();

        Trajectory third_specimen_to_submersible = drive.trajectoryBuilder(new Pose2d(21, -17, Math.toRadians(-135)))
                .splineToLinearHeading (new Pose2d(22.5, 22.5, Math.toRadians(0)), Math.toRadians(0))
                .build();

        Trajectory slight_fwd2 = drive.trajectoryBuilder(new Pose2d (22.5, 22.5, Math.toRadians(0)))
                .forward (3)
                .build();

        Trajectory back3 = drive.trajectoryBuilder(new Pose2d(25.5, 22.5, Math.toRadians(0)))
                .back(7.5)
                .build();


         */



        /*

        Trajectory to_human_player = drive.trajectoryBuilder (new Pose2d(19, 7.5, Math.toRadians(0)))
                .lineToSplineHeading(new Pose2d(19.5, -19.5, Math.toRadians(-135)))
                .build();

        Trajectory drive_to_submersible_second = drive.trajectoryBuilder(new Pose2d(21.5, -19.5, Math.toRadians(-135)))
                .splineToLinearHeading(new Pose2d(28, 13.5, Math.toRadians(0)), Math.toRadians(0))
                .build();

        Trajectory fwd = drive.trajectoryBuilder(new Pose2d(28, 13.5, Math.toRadians(0)))
                .forward(1.5)
                .build();

        Trajectory back2 = drive.trajectoryBuilder(new Pose2d(29.5, 10.5, Math.toRadians(0)))
                .back(10)
                .build();

        Trajectory park = drive.trajectoryBuilder(new Pose2d(21, 7.5, Math.toRadians(0)))
                .lineTo(new Vector2d(8.5, -23.5))
                .build();


         */

        waitForStart();

        if(isStopRequested()) return;

        drive.followTrajectory(drive_to_submersible);

        liftRotateMotor.setTargetPosition(625);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        drive.followTrajectory(back);

        liftRotateMotor.setTargetPosition(150);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        LeftClawServo.setPosition(0.35);
        RightClawServo.setPosition(0.65);

        sleep (250);

        drive.followTrajectory(to_ground_specimen_strafe);

        liftRotateMotor.setTargetPosition(45);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        LeftClawServo.setPosition(1);
        RightClawServo.setPosition(0);

        sleep (250);

        liftRotateMotor.setTargetPosition(75);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        drive.followTrajectory(backward_human_player_delivery);

        sleep (250);

        LeftClawServo.setPosition(0.35);
        RightClawServo.setPosition(0.65);

        sleep (250);

        drive.followTrajectory(backward_realignment_for_second);

        sleep (1500);

        drive.followTrajectory(second_fwd);

        sleep (250);

        liftRotateMotor.setTargetPosition(45);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        LeftClawServo.setPosition(1);
        RightClawServo.setPosition(0);

        sleep (250);

        liftRotateMotor.setTargetPosition(500);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        drive.followTrajectory(second_specimen_to_submersible);

        drive.followTrajectory(slight_fwd);

        liftRotateMotor.setTargetPosition(625);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        drive.followTrajectory(back2);

        sleep (250);

        LeftClawServo.setPosition(0.35);
        RightClawServo.setPosition(0.65);

        sleep (100);

        liftRotateMotor.setTargetPosition(150);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        drive.followTrajectory(right_strafe_after_second);

        sleep (100);

        drive.followTrajectory(diagonal_sweep);

        sleep(100);
        drive.followTrajectory(left_sweep);

        /*

        liftRotateMotor.setTargetPosition(150);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        LeftClawServo.setPosition(0.35);
        RightClawServo.setPosition(0.65);

        sleep (250);

        drive.followTrajectory(to_human_player_third_specimen);

        sleep (250);

        liftRotateMotor.setTargetPosition(45);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        LeftClawServo.setPosition(1);
        RightClawServo.setPosition(0);

        sleep (250);

        liftRotateMotor.setTargetPosition(500);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        drive.followTrajectory(third_specimen_to_submersible);

        drive.followTrajectory(slight_fwd2);

        liftRotateMotor.setTargetPosition(625);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        drive.followTrajectory(back3);

        LeftClawServo.setPosition (0.35);
        RightClawServo.setPosition(0.65);

        sleep (250);




        /*

        drive.followTrajectory(to_human_player);

        sleep (250);

        liftRotateMotor.setTargetPosition(55);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        LeftClawServo.setPosition(1);
        RightClawServo.setPosition(0);

        sleep (250);

        liftRotateMotor.setTargetPosition(500);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        drive.followTrajectory(drive_to_submersible_second);

        sleep (250);

        drive.followTrajectory(fwd);

        liftRotateMotor.setTargetPosition(625);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        drive.followTrajectory(back);

        sleep (250);

        liftRotateMotor.setTargetPosition(150);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        LeftClawServo.setPosition(0.35);
        RightClawServo.setPosition(0.65);



        sleep (250);

        drive.followTrajectory(to_human_player);
        sleep (250);

        liftRotateMotor.setTargetPosition(55);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (250);

        LeftClawServo.setPosition(1);
        RightClawServo.setPosition(0);

        sleep (100);

        liftRotateMotor.setTargetPosition(500);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (100);

        drive.followTrajectory(drive_to_submersible_second);

        sleep (100);

        drive.followTrajectory(fwd);

        liftRotateMotor.setTargetPosition(625);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setPower(0.6);

        sleep (100);

        drive.followTrajectory(back2);

        sleep (100);

        LeftClawServo.setPosition(0.35);
        RightClawServo.setPosition(0.65);

        sleep (100);


         */

    }

}