package org.firstinspires.ftc.teamcode.drive;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import com.qualcomm.hardware.dfrobot.HuskyLens;
import com.qualcomm.hardware.rev.Rev2mDistanceSensor;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DistanceSensor;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.internal.system.Deadline;

import java.util.concurrent.TimeUnit;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;

import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name="Driver Control - RR Compatible", group="Linear Opmode")


public class DriverControl extends LinearOpMode {
    @Override
    public void runOpMode() throws InterruptedException {
// Declaration and mapping of lift motors.
        DistanceSensor sensorDistance;

// Declaration and mapping of drive motors.
        DcMotor motorFrontLeft = hardwareMap.dcMotor.get("leftFront");
        DcMotor motorBackLeft = hardwareMap.dcMotor.get("leftRear");
        DcMotor motorFrontRight = hardwareMap.dcMotor.get("rightFront");
        DcMotor motorBackRight = hardwareMap.dcMotor.get("rightRear");

        // Extend and rotate
        DcMotor liftExtendMotor = hardwareMap.dcMotor.get("liftExtendMotor");
        DcMotor liftExtendMotor1 = hardwareMap.dcMotor.get("liftExtendMotor1");
        DcMotor liftRotateMotor = hardwareMap.dcMotor.get("liftRotateMotor");

        DistanceSensor sensor = hardwareMap.get(DistanceSensor.class, "sensor");

        liftExtendMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        liftExtendMotor1.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        liftRotateMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        liftExtendMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        liftExtendMotor1.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        liftExtendMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        liftExtendMotor1.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//Set target position and power of lift motors
        liftExtendMotor.setTargetPosition(0);
        liftExtendMotor1.setTargetPosition(0);
        liftRotateMotor.setTargetPosition(0);


        liftExtendMotor.setPower(0.8);
        liftExtendMotor1.setPower(0.8);
        liftRotateMotor.setPower(0.3);


//Declaration and mapping of the claw Servo

        Servo LeftClawServo = hardwareMap.get(Servo.class, "LeftClawServo");
        Servo RightClawServo = hardwareMap.get(Servo.class, "RightClawServo");
        Servo LiftServo = hardwareMap.get(Servo.class, "LiftServo");


// Reverse the right side motors
        motorBackLeft.setDirection(DcMotor.Direction.FORWARD);
        motorFrontRight.setDirection(DcMotor.Direction.REVERSE);
        motorBackRight.setDirection(DcMotor.Direction.REVERSE);
        motorFrontLeft.setDirection(DcMotor.Direction.FORWARD);

        telemetry.addData("extend", liftExtendMotor.getCurrentPosition());
        telemetry.addData("rotate", liftRotateMotor.getCurrentPosition());
        telemetry.update();


        waitForStart();

        liftExtendMotor.setPower(0.8);
        liftExtendMotor1.setPower(0.8);
        liftRotateMotor.setPower(0.3);

        boolean isClosed = false;

        double position = 0;
        double right1 = 0;
        double left1 = 0;

        int currentPosition = 0;
        int rotatePosition = 0;

        boolean left = false;
        boolean right = false;

        boolean highlevel = false;
        boolean proxyFlag = true;


        int position2 = 0;
        final double TRIGGER_THRESHOLD = 0.75;

        while (opModeIsActive()) {

//Drive Motor Code!
//Not to be messed with under any circumstances.
            liftExtendMotor.setPower(0.8);
            liftExtendMotor1.setPower(0.8);
            liftRotateMotor.setPower(0.3);

            ElapsedTime runtime = new ElapsedTime();
            double y = gamepad1.left_stick_y;
            double rx = -gamepad1.right_stick_x * 1.1;
            double x = -gamepad1.left_stick_x;

// Stupid Code
            double y2 = gamepad2.left_stick_y;
            double rx2 = -gamepad2.right_stick_x * 1.1;
            double x2 = -gamepad2.left_stick_x;

            telemetry.addLine("left stick y" + y);
            telemetry.addLine("left stick x" + x);
            telemetry.addLine("right stick x" + rx);
// telemetry.addLine("servo pos: " + rightliftServo.getPosition());


            double denominator = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);
            double frontLeftPower = (y + x + rx) / denominator;
            double backLeftPower = (y - x + rx) / denominator;
            double frontRightPower = (y - x - rx) / denominator;
            double backRightPower = (y + x - rx) / denominator;

            double denominator2 = Math.max(Math.abs(y2) + Math.abs(x2) + Math.abs(rx2), 1);
            double frontLeftPower2 = (y2 + x2 + rx2) / denominator2;
            double backLeftPower2 = (y2 - x2 + rx2) / denominator2;
            double frontRightPower2 = (y2 - x2 - rx2) / denominator2;
            double backRightPower2 = (y2 + x2 - rx2) / denominator2;


            if (gamepad1.left_stick_y >= 0.1 || gamepad1.left_stick_x >= 0.1 || gamepad1.left_stick_y <= -0.1 || gamepad1.left_stick_x <= -0.1 || gamepad1.right_stick_y >= 0.2 || gamepad1.right_stick_x >= 0.2 || gamepad1.right_stick_y <= -0.2 || gamepad1.right_stick_x <= -0.2) {
                motorFrontLeft.setPower(frontLeftPower * 0.85);
                motorBackLeft.setPower(backLeftPower * 0.85);
                motorFrontRight.setPower(frontRightPower * 0.85);
                motorBackRight.setPower(backRightPower * 0.85);
            } else if (gamepad2.left_stick_y >= 0.1 || gamepad2.left_stick_x >= 0.1 || gamepad2.left_stick_y <= -0.1 || gamepad2.left_stick_x <= -0.1 || gamepad2.right_stick_y >= 0.1 || gamepad2.right_stick_x >= 0.1 || gamepad2.right_stick_y <= -0.1 || gamepad2.right_stick_x <= -0.1) {
                motorFrontLeft.setPower(frontLeftPower2 * 0.3);
                motorBackLeft.setPower(backLeftPower2 * 0.3);
                motorFrontRight.setPower(frontRightPower2 * 0.3);
                motorBackRight.setPower(backRightPower2 * 0.3);
            } else {
                motorFrontLeft.setPower(0);
                motorBackLeft.setPower(0);
                motorFrontRight.setPower(0);
                motorBackRight.setPower(0);
            }
//Lift Motor Code
// Find starting height for lift and find power at that point
// Find final height and power and map that to the claw orientation (position 0 < x < 1)

            double liftPowerDown = gamepad1.left_trigger;
            double liftPowerUp = gamepad1.right_trigger;

            double liftPowerDown2 = gamepad2.left_trigger;
            double liftPowerUp2 = gamepad2.right_trigger;

            //Claw code - Proximity sensors


            if (gamepad1.dpad_left) {
                motorFrontLeft.setPower(0.8);
                motorBackLeft.setPower(-0.8);
                motorFrontRight.setPower(-0.8);
                motorBackRight.setPower(0.8);
            } else if (gamepad2.dpad_left) {
                motorFrontLeft.setPower(0.3);
                motorBackLeft.setPower(-0.3);
                motorFrontRight.setPower(-0.3);
                motorBackRight.setPower(0.3);
            }

            if (gamepad1.dpad_right) {
                motorFrontLeft.setPower(-0.8);
                motorBackLeft.setPower(0.8);
                motorFrontRight.setPower(0.8);
                motorBackRight.setPower(-0.8);
            } else if (gamepad2.dpad_right) {
                motorFrontLeft.setPower(-0.3);
                motorBackLeft.setPower(0.3);
                motorFrontRight.setPower(0.3);
                motorBackRight.setPower(-0.3);
            }

            if (gamepad1.dpad_right) {
                if (currentPosition >= -1000) {
                    liftExtendMotor.setPower(0.8);
                    liftExtendMotor1.setPower(0.8);
                    currentPosition = liftExtendMotor.getCurrentPosition() - 100;
                    sleep(1);
                    liftExtendMotor.setTargetPosition(currentPosition);
                    liftExtendMotor1.setTargetPosition(-currentPosition);
                    telemetry.addData("current1", currentPosition);
                    telemetry.addData("current1", -currentPosition);
                    telemetry.update();
                }
                if (currentPosition <= -1000) {
                    liftExtendMotor.setTargetPosition(-1000);
                    liftExtendMotor1.setTargetPosition(-1000);
                }
            } else if (gamepad2.dpad_down) {
                if (currentPosition >= -1000) {
                    liftExtendMotor.setPower(0.8);
                    liftExtendMotor1.setPower(0.8);
                    currentPosition = liftExtendMotor.getCurrentPosition() - 100;
                    sleep(1);
                    liftExtendMotor.setTargetPosition(currentPosition);
                    liftExtendMotor1.setTargetPosition(-currentPosition);
                    telemetry.addData("current1", currentPosition);
                    telemetry.addData("current1", -currentPosition);
                    telemetry.update();
                }
                if (currentPosition <= -1000) {
                    liftExtendMotor.setTargetPosition(-1000);
                    liftExtendMotor1.setTargetPosition(-1000);
                }
            }

            if (gamepad1.left_bumper) {
                if (currentPosition >= 0) {
                    liftExtendMotor.setPower(0.8);
                    liftExtendMotor1.setPower(0.8);
                    currentPosition = liftExtendMotor.getCurrentPosition() - 1300;
                    sleep(1);
                    liftExtendMotor.setTargetPosition(currentPosition);
                    liftExtendMotor1.setTargetPosition(-currentPosition);
                    telemetry.addData("current1", currentPosition);
                    telemetry.addData("current1", -currentPosition);
                    telemetry.update();
                }
                if (currentPosition <= 0) {
                    liftExtendMotor.setTargetPosition(0);
                    liftExtendMotor1.setTargetPosition(0);
                }
            } else if (gamepad2.left_bumper) {
                if (currentPosition >= 0) {
                    liftExtendMotor.setPower(0.8);
                    liftExtendMotor1.setPower(0.8);
                    currentPosition = liftExtendMotor.getCurrentPosition() - 1300;
                    sleep(1);
                    liftExtendMotor.setTargetPosition(currentPosition);
                    liftExtendMotor1.setTargetPosition(-currentPosition);
                    telemetry.addData("current1", currentPosition);
                    telemetry.addData("current1", -currentPosition);
                    telemetry.update();
                }
                if (currentPosition <= 0) {
                    liftExtendMotor.setTargetPosition(0);
                    liftExtendMotor1.setTargetPosition(0);
                }
            }
            if (gamepad1.right_bumper) {
                if (currentPosition <= 3100) {
                    currentPosition = liftExtendMotor.getCurrentPosition() + 630;
                    sleep(1);
                    liftExtendMotor.setTargetPosition(currentPosition);
                    liftExtendMotor1.setTargetPosition(-currentPosition);
                    telemetry.addData("current1", currentPosition);
                    telemetry.update();
                }
                if (currentPosition >= 3100) {
                    liftExtendMotor.setTargetPosition(3140);
                    liftExtendMotor1.setTargetPosition(-3100);
                }
            } else if (gamepad2.right_bumper) {
                if (currentPosition <= 3100) {
                    currentPosition = liftExtendMotor.getCurrentPosition() + 630;
                    sleep(1);
                    liftExtendMotor.setTargetPosition(currentPosition);
                    liftExtendMotor1.setTargetPosition(-currentPosition);
                    telemetry.addData("current1", currentPosition);
                    telemetry.update();
                }
                if (currentPosition >= 3100) {
                    liftExtendMotor.setTargetPosition(3140);
                    liftExtendMotor1.setTargetPosition(-3100);
                }
            }
            //Rotate the arm
            if (gamepad1.right_trigger >= .3) {
                if (rotatePosition >= -4000) {
                    rotatePosition = liftRotateMotor.getCurrentPosition() - 30;
                    sleep(1);
                    liftRotateMotor.setTargetPosition(rotatePosition);
                    telemetry.addData("rotate1", rotatePosition);
                    telemetry.update();
                }
            } else if (gamepad2.right_trigger >= .3) {
                if (rotatePosition >= -4000) {
                    rotatePosition = liftRotateMotor.getCurrentPosition() - 30;
                    sleep(1);
                    liftRotateMotor.setTargetPosition(rotatePosition);
                    telemetry.addData("rotate1", rotatePosition);
                    telemetry.update();
                }
            }
            if (gamepad1.left_trigger >= .3) {
                if (rotatePosition <= 1200) {
                    rotatePosition = liftRotateMotor.getCurrentPosition() + 30;
                    sleep(1);
                    liftRotateMotor.setTargetPosition(rotatePosition);
                    telemetry.addData("rotate1", rotatePosition);
                    telemetry.update();
                }
            } else if (gamepad2.left_trigger >= .3) {
                if (rotatePosition <= 1200) {
                    rotatePosition = liftRotateMotor.getCurrentPosition() + 30;
                    sleep(1);
                    liftRotateMotor.setTargetPosition(rotatePosition);
                    telemetry.addData("rotate1", rotatePosition);
                    telemetry.update();
                }
            }


            if (gamepad1.y || gamepad2.y){
                liftRotateMotor.setTargetPosition(-200);
                liftRotateMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
                liftRotateMotor.setPower(0.25);
            }


            if (isClosed == false) {
                if (sensor.getDistance(DistanceUnit.MM) <= 70) {
                    LeftClawServo.setPosition(1);
                    RightClawServo.setPosition(0);

                    isClosed = true;

                }

                if (gamepad1.b) {
                    LeftClawServo.setPosition(1);
                    RightClawServo.setPosition(0);

                    isClosed = true;
                }

                if (gamepad2.b) {
                    LeftClawServo.setPosition(1);
                    RightClawServo.setPosition(0);

                    isClosed = true;
                }

            } else {
                if (gamepad1.a) {
                    LeftClawServo.setPosition(0.35);
                    RightClawServo.setPosition(0.65);

                    isClosed = false;
                }

                if (gamepad2.a) {
                    LeftClawServo.setPosition(0.35);
                    RightClawServo.setPosition(0.65);

                    isClosed = false;
                }



                    /*
                    if (sensor.getDistance(DistanceUnit.MM) >= 70) {
                        isClosed = false;
                        telemetry.addLine("nut in muhaddas");
                        telemetry.update();
                    }


                     */
                }

            /*
            if(gamepad1.a && !(isClosed))
            {
                LeftClawServo.setPosition(1);
                RightClawServo.setPosition(0);
                isClosed = true;
                sleep(100);

            }

            else if(gamepad1.a && isClosed)
            {
                proxyFlag = false;

                LeftClawServo.setPosition(0.35);
                RightClawServo.setPosition(0.65);

                isClosed = false;

                runtime.reset();

                sleep(100);
            }

            else if(gamepad2.a && !(isClosed))
            {
                LeftClawServo.setPosition(1);
                RightClawServo.setPosition(0);
                isClosed = true;
                sleep(100);

            }
            else if(gamepad2.a && isClosed)
            {
                proxyFlag = false;

                LeftClawServo.setPosition(0.35);
                RightClawServo.setPosition(0.65);
                isClosed = false;


                runtime.reset();
                sleep(100);
            }

            if (runtime.seconds() > 5.0){
                proxyFlag = true;
            }

            if (sensor.getDistance(DistanceUnit.MM) <= 45 && proxyFlag){
                LeftClawServo.setPosition(1);
                RightClawServo.setPosition(0);
                isClosed = true;
            }

            if (sensor.getDistance(DistanceUnit.MM) > 75){
                isClosed = false;
            }


             */


                telemetry.addData("extend", liftExtendMotor.getCurrentPosition());
                telemetry.addData("extend1", liftExtendMotor1.getCurrentPosition());
                telemetry.addData("rotate", liftRotateMotor.getCurrentPosition());
                telemetry.addData("position", LiftServo.getPosition());
                telemetry.addData("isClosed", isClosed);
                telemetry.addLine("nut in minidas");
                telemetry.update();


            }
        }
    }
